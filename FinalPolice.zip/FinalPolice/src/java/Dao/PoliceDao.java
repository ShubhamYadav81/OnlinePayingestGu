/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;
import java.sql.*;
import model.*;
import MyConnection.MyCon;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author shubham
 */
public class PoliceDao
{
  public List<Tenent> searchAll()throws Exception
        {
           Connection Con=null;
           PreparedStatement ps=null;
           Con=MyCon.getConnection();
           ResultSet rs=null;
           String sql="select id,Name,Aadhar_number,Fathers_name,Permanent_address,Mobile,Other_detail,Work_place,Work_place_address,Work_place_mobile_,Occupation,Guardians_name,Guardians_mobile,Guardians_address from Tenent";
           ps=Con.prepareStatement(sql);
           rs=ps.executeQuery();
          List <Tenent>mylist=new  ArrayList <Tenent>();
          while(rs.next())
          {
           Tenent S=new Tenent();
           S.setId1(rs.getString(1));
           S.setName(rs.getString(2));
           S.setAadhar_number(rs.getString(3));
           S.setFathers_name(rs.getString(4));
           S.setPermanent_address(rs.getString(5));
           S.setMobile(rs.getString(6));
           S.setOther_detail(rs.getString(7));
           S.setWork_place(rs.getString(8));
           S.setWork_place_address(rs.getString(9));
           S.setWork_place_mobile(rs.getString(10));
           S.setOccupation(rs.getString(11));
           S.setGuardians_name(rs.getString(12));
           S.setGuardians_mobile(rs.getString(13));
           S.setGuardians_address(rs.getString(14));
           
           mylist.add(S);
    
          }
          return mylist;
        }
  public Owner record(String s)
  {
           Connection Con=null;
           PreparedStatement ps=null;
           Con=MyCon.getConnection();
           ResultSet rs=null;
           String sql="select * from Owner where id=?";
            Owner O=new Owner();
          try
          { 
           ps=Con.prepareStatement(sql);
           ps.setString(1,s);
           rs=ps.executeQuery(); 
           while(rs.next())
           {
              O.setId(rs.getString(1));
              O.setName(rs.getString(2));
              O.setFatherName(rs.getString(3));
              O.setMobile(rs.getString(4));
              O.setPoliceStation(rs.getString(5));
              O.setAddress(rs.getString(6));
           }
          }
          catch(Exception e)
          {
            System.out.println(e);
          }
          return O;
  }
  
  public boolean registrationPolice(PoliceLogin P)
  {
          PreparedStatement ps=null;
          Connection con=null;
        try
        {   
            con=MyCon.getConnection();
            String sql="insert into PoliceLogin values(?,?,?,?,?)";
            ps=con.prepareStatement(sql);
            ps.setString(1,P.getPoliceId());
            ps.setString(2,P.getPoliceName());
            ps.setString(3,P.getPoliceCity());
            ps.setString(4,P.getPolicePhone());
            ps.setString(5,P.getPassword());           
            if(ps.executeUpdate()>0)
            {
             return true;   
            }
          
        }
        catch(Exception e)
        {
            System.out.println(e);   
        }
          return false;             
  }
      public String policeLogin(String id,String password)
    {
    
        PreparedStatement ps=null;
        ResultSet rs=null;
        Connection con=null;
        String pass=null;
        try
        {   
            con=MyCon.getConnection();
            String sql="select * from PoliceLogin where Id=?";
            ps =con.prepareStatement(sql);
            ps.setString(1,id);
            rs=ps.executeQuery();
            if(rs.next())
            {
             // count++;
                rs.getString(1);
                rs.getString(2);
                rs.getString(3);
                rs.getString(4);
                pass=rs.getString(5);              
            }          
         }       
       catch(Exception e) 
       {
           System.out.println(e);
       }
    
           return pass; 
     } 
}
