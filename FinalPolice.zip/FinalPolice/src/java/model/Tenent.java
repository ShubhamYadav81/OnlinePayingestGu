/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author shubham
 */
public class Tenent 
{
    private String id1; 
    private String Name;
    private String Aadhar_number;
    private String Fathers_name;
    private String Permanent_address;
    private String Mobile;
    private String Other_detail;
    private String Work_place;
    private String Work_place_address;
    private String Work_place_mobile;
    private String Occupation;
    private String Guardians_name;
    private String Guardians_mobile;
    private String Guardians_address;
   
   
    
    public String getId1() {
        return id1;
    }

    public void setId1(String id1) {
        this.id1 = id1;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getAadhar_number() {
        return Aadhar_number;
    }

    public void setAadhar_number(String Aadhar_number) {
        this.Aadhar_number = Aadhar_number;
    }

    public String getFathers_name() {
        return Fathers_name;
    }

    public void setFathers_name(String Fathers_name) {
        this.Fathers_name = Fathers_name;
    }

    public String getPermanent_address() {
        return Permanent_address;
    }

    public void setPermanent_address(String Permanent_address) {
        this.Permanent_address = Permanent_address;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String Mobile) {
        this.Mobile = Mobile;
    }

    public String getOther_detail() {
        return Other_detail;
    }

    public void setOther_detail(String Other_detail) {
        this.Other_detail = Other_detail;
    }

    public String getWork_place() {
        return Work_place;
    }

    public void setWork_place(String Work_place) {
        this.Work_place = Work_place;
    }

    public String getWork_place_address() {
        return Work_place_address;
    }

    public void setWork_place_address(String Work_place_address) {
        this.Work_place_address = Work_place_address;
    }

    public String getWork_place_mobile() {
        return Work_place_mobile;
    }

    public void setWork_place_mobile(String Work_place_mobile) {
        this.Work_place_mobile = Work_place_mobile;
    }

    public String getOccupation() {
        return Occupation;
    }

    public void setOccupation(String Occupation) {
        this.Occupation = Occupation;
    }

    public String getGuardians_name() {
        return Guardians_name;
    }

    public void setGuardians_name(String Guardians_name) {
        this.Guardians_name = Guardians_name;
    }

    public String getGuardians_mobile() {
        return Guardians_mobile;
    }

    public void setGuardians_mobile(String Guardians_mobile) {
        this.Guardians_mobile = Guardians_mobile;
    }

    public String getGuardians_address() {
        return Guardians_address;
    }

    public void setGuardians_address(String Guardians_address) {
        this.Guardians_address = Guardians_address;
    }

}
